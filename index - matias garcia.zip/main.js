const products = [
    { id: 1, name: "Gancia", price: 450, stock: 20 },
    { id: 2, name: "Fernet", price: 750, stock: 30 },
    { id: 3, name: "Smirnof", price: 550, stock: 15 },
    { id: 4, name: "Quilmes", price: 150, stock: 50 },
];

for (const product of products) {
    let contenedor = document.createElement("div");
    //Definimos el innerHTML del elemento con una plantilla de texto
    contenedor.innerHTML = `<h3> ID: ${product.id}</h3>
                            <p>  Producto: ${product.name}</p>
                            <b> $ ${product.price}</b>`;
    document.body.appendChild(contenedor);
}